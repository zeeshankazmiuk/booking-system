Welcome to the collection of my coursework from my 2nd year at uni!

The folders you see in front of you are named after each module I took over the past year, and contain their respective courseworks.
